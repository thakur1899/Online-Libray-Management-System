package com.RCEW.www.service;

import com.RCEW.www.entity.Books;

public interface ServicelayerInter {

	void saveBook(Books books);
	
	

}
