package com.RCEW.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	
	
	@GetMapping("/login")
	public String loginPage() {
		
		
		
		return "admin_login";
	}
	
	
	@GetMapping("/access-denied")
	public String deniedPage() {
		
		return "access-denied";
	}


}
