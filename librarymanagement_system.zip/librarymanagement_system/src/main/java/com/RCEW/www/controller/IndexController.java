package com.RCEW.www.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.RCEW.www.entity.Books;
import com.RCEW.www.service.ServicelayerInter;



@Controller
public class IndexController {
	
	@Autowired
	ServicelayerInter servicelayer;
	

	@GetMapping("/")
	public String indexcls() {
		
		return "indexpage";
	}
	
	

	@GetMapping("/adminlog")
	public String adminView() {
		
		return "admin_view";
	}
	
	@GetMapping("/addbook")
	public String addbooks(Model model) {
		
		Books books = new Books();
		
		model.addAttribute("book",books);
		
		return "add_books";
	}
	
	@PostMapping("/book_save")
	public String saveStudentData( @ModelAttribute("book") Books books) {
		
		
		servicelayer.saveBook(books);
			return "redirect:/adminlog";
		
	}
	
	
	@GetMapping("/issue_book")
	public String issuebook() {
		
		return "issue_books";
	}
}
