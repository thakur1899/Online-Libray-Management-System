package com.RCEW.www.dao;

import com.RCEW.www.entity.Books;

public interface BookDao {

	void saveBook(Books books);

}
