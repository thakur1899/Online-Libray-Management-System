package com.RCEW.www.entity;

public class Issuebooks {

	private int bookid;
	private String title;
	private String publication;
	private int studentid;
	private int dateofissue;
	private int dateofreturn;
	private int bookbankid;
	
	
	
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPublication() {
		return publication;
	}
	public void setPublication(String publication) {
		this.publication = publication;
	}
	public int getStudentid() {
		return studentid;
	}
	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}
	public int getDateofissue() {
		return dateofissue;
	}
	public void setDateofissue(int dateofissue) {
		this.dateofissue = dateofissue;
	}
	public int getDateofreturn() {
		return dateofreturn;
	}
	public void setDateofreturn(int dateofreturn) {
		this.dateofreturn = dateofreturn;
	}
	public int getBookbankid() {
		return bookbankid;
	}
	public void setBookbankid(int bookbankid) {
		this.bookbankid = bookbankid;
	}
	
	
	
}
