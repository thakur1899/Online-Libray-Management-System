package com.RCEW.www.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class AdminController {
	
	
	
	
	
	@GetMapping("/addlibrarian")
	public String addLibraian() {
		
		return "add_librarian";
	}
	
	@GetMapping("/viewlibrarian")
	public String viewLibrarian() {
		
		return "view_librarian";
	}
	
	
	public String deleteLibrarian() {
		
		return "null";
	}
	
	
	
	

}
