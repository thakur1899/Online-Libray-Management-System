package com.RCEW.www.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.RCEW.www.entity.Books;

@Repository
public class BookDaoimplt implements BookDao {
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public void saveBook(Books books) {
		
		Session session = sessionFactory.getCurrentSession();
		
		//Student Details save or update both functionality work this method
		session.saveOrUpdate(books);
	}

}
