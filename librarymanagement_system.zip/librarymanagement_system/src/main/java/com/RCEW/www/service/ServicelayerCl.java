package com.RCEW.www.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.RCEW.www.dao.BookDao;
import com.RCEW.www.entity.Books;

@Service
public class ServicelayerCl implements ServicelayerInter {
	
	@Autowired
	BookDao bookDao;

	@Override
	@Transactional
	public void saveBook(Books books) {
		
		bookDao.saveBook(books);
		
	}
	

}
